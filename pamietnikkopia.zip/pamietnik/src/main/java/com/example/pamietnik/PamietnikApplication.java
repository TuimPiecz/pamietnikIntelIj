package com.example.pamietnik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PamietnikApplication {

    public static void main(String[] args) {
        SpringApplication.run(PamietnikApplication.class, args);
    }

}
