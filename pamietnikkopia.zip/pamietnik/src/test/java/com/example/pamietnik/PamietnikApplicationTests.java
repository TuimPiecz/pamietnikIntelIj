package com.example.pamietnik;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PamietnikApplicationTests {

    @Test
    void contextLoads() {
    }

}
